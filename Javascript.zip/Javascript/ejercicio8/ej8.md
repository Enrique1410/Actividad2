#EJERCICIO 8: Gráficas con ChartJS

En este ejercicio simularemos un recuento electoral. Supondremos que celebramos unas elecciones a las que se presentan 5 partidos.

1. Tendremos 5 botones, uno para cada partido. Al clicar el botón de un partido, se añade un voto a ese partido.

2. Cada nuevo voto se verá reflejado al momento en un gráfico circular (Pie Chart o Doughnut chart), tal como se ve en la imagen.

3. También tendremos un botón de reset, que pondrá todos los votos a 0, y podremos volver a empezar la votación.
