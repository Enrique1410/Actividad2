#EJERCICIO 6: Manipular visibilidad de elementos (II)

A partir de la página web proporcionada, completad el código JavaScript para que:

1. Cuando se pinche sobre el primer enlace, se oculte su sección relacionada
2. Cuando se vuelva a pinchar sobre el mismo enlace, se muestre otra vez esa sección de contenidos
3. Completar el resto de enlaces de la página para que su comportamiento sea idéntico al del primer enlace
4. Cuando una sección se oculte, debe cambiar el mensaje del enlace asociado (Cambiar la palabra "ocultar" por "mostrar", y viceversa)
