#EJERCICIO 1 Mensajes y alertas (I)

Modificar el script del fichero ej1.html para que:

1. Todo el código JavaScript se encuentre en un archivo externo llamado codigo.js y el script siga funcionando de la misma manera.

2. Después del primer mensaje, se debe mostrar otro mensaje que diga "Soy el primer script"
