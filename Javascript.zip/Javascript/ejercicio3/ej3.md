#EJERCICIO 3: Mensajes y alertas (III)

Modificar el script del fichero ej3.html para que:

1. El mensaje se muestre con una ventana de confirmación, y no por consola ni con una alerta. Tal como se ve en la imagen (Tened en cuenta que en Safari se ve como en la imagen, pero otros navegadores cambiarán el estilo. Esto no es un problema ni un error).

2. Si se clica el botón de confirmación, debe por consola el mensaje "Has clicado OK".

3. Si se clica el botón de cancelación, debe por consola el mensaje "Has clicado Cancelar".
