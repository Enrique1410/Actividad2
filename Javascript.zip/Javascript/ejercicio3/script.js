let message = "Hola Mundo!";

if (confirm(message)) {
    console.log("Has clicado OK");
} else {
    console.log("Has clicado Cancelar")
};